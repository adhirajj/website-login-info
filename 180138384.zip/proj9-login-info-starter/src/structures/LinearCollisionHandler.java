package structures;

import java.security.DrbgParameters.Capability;

import javax.print.attribute.standard.Sides;

public class LinearCollisionHandler <K> implements CollisionHandler <K>{
    private int probeLength;

    /**
  * Constructors to set probeLength to 1, or a different length.
  */
    public LinearCollisionHandler(){
        this.probeLength = 1;
    }

    public LinearCollisionHandler(int probeLength){
        this.probeLength = probeLength;
    }

/**
  * Method starts at index and searches linearly until an open spot
  * is found in the array. This could include index itself.
  * index = (index + probeLength) % size
  */
   public int probe(int index, boolean[] activeArray, int M) {
      //TODO: Implement this method.
      while(activeArray[index] !=false) {
        index = (index + probeLength) % M;
      }
      return index;
      // for (int i = index; i<M; i++) {
      //   if (activeArray[curIndex]) {
      //     curIndex = (curIndex + probeLength) % M;
      //   }
      // }
      // return curIndex;
   }

  /**
* Start at index and search the array linearly until the target
* is found. Then return the array index of the target. 
* Return -1 if not found.
*/
   public int search(int startIndex, K target, K[] keyArray, boolean [] activeArray, int M){
      //TODO: Implement this method.
      // while (keyArray[startIndex] != target && activeArray[startIndex] != true) {
      //   startIndex++;
      // }
      // if (keyArray[startIndex] == target) {
      //   return startIndex;
      // }
      // return -1;
      int curIndex = startIndex;
      for (int i = startIndex; i<M ; i++) {
        if(keyArray[curIndex] == null && activeArray[curIndex] == false) { 
          return -1;
        }
        if (keyArray[curIndex].equals(target) && activeArray[curIndex] == true) {
          return curIndex;
        }else{
          curIndex = (curIndex + probeLength) % M;
        }
      }
      return -1;
  //     for (int i = startIndex; i < M; i++) {
  //       if (keyArray[i] == target && activeArray[i] == true) {
  //         return i;
  //       }
  //     }
  //     return -1;
   }
}
